<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Obfuscapery Demo</title>
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<!-- *EDIT ME* CHANGE URL TO THE  LOCATION OF THE JS FILE ON YOUR SERVER vvv***-->
<script src="obfuscapery.js" type="text/javascript"></script>
<!-- *EDIT ME* CHANGE URL TO THE  LOCATION OF THE JS FILE ON YOUR SERVER ^^^***-->
</head>

<body>
<div id="mailto_0"><a href="">Loading 0 ...</a></div>
<div id="mailto_2"><a href="">Loading 2 ...</a></div>
<div id="mailto_1"><a href="">Loading 1 ...</a></div>
<!-- *EDIT ME* CHANGE PATH TO THE ACTUAL LOCATION OF THIS INCLUDE ON YOUR SERVER vvv** -->
<?php include('obfuscapery.inc.php'); ?>
<!-- *EDIT ME* CHANGE PATH TO THE ACTUAL LOCATION OF THIS INCLUDE ON YOUR SERVER ^^^** -->
</body>
</html>