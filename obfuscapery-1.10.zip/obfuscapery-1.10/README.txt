/*******************************
********   OBFUSCAPERY   *******
********************************
* Version 1.10                 *
* (c)2011 Lilaea Media LLC     *
********************************
************************************************************************************
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.
***********************************************************************************/


Installation:

1. Copy the entire Obfuscapery-1.10 folder to your web server in a non-public location for testing.
2. Load the demo in your browser by going to http://yourdomain/path/to/obfuscapery-1.10/example.php
3. Move your mouse. The sample email addresses should appear. 
4. Review the scripts.
5. When you are ready, customize (steps 1-9 below).

Customization:

1. Open obfuscapery.inc.php in your favorite editor. 
2. Change the email addresses in the $emails array to addresses for your site. 
3. Make a note of their position in the array. If the same address needs to appear more than once on 
    a page, it must have a separate entry in the array because its corresponding <div> tags must be unique.
4. Configure PHP options:
    a. Change $decode_secret to a private value. The number of characters will also determine the length of the random secret key.
    b. Set $verify_origin to true or false depending on your preference. This tells the script to compare HTTP_HOST to HTTP_REFERER to validate XHR posts.
    c. Change $descriptor so that it is not obviously an Obfuscapery container. This must match the descriptor variable in obfuscapery.js.
    d. Change $prefix to for the same reason.
5. Copy obfuscapery.inc.php to your php includes folder if you have one or anywhere you feel is appropriate. It must reside in a publicly accessible location.
6. Open obfuscapery.js in your favorite editor.
7. Configure JS options:
    a. Edit the value of url to point to the relative location of obfuscapery.inc.php
    b. Edit the output of the actual mailto: link as you see fit in the swapMailto() JS method.
    c. If the descriptor was modified in step 4, change the value of the descriptor variable to match the PHP value.
8. Copy obfuscapery.js to your js folder if you have one or anywhere you feel is appropriate. It must reside in a publicly accessible location.
9. Edit each PHP page that requires Obfuscapery (steps 1-7 below).

Edit PHP Pages:

1. Add the script src tags to the HEAD of the HTML:
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="path/to/obfuscapery.js" type="text/javascript"></script>
2. If you want to host a local instance of JQuery, install it and point the above tag there. www.jquery.com
3. Insert the PHP include somewhere between <body> and </body>. This will contain the encrypted email <div> tags.
   It must point to the relative file path of obfuscapery.inc.php on your server:
    <?php include('path/to/obfuscapery.inc.php'); ?>
4. Insert a <div> container wherever you want the email to appear. 
    The id attribute must start with "mailto_" followed by the array key of that email.
    <div id="mailto_0">Loading...</div>
5. Copy the edited PHP pages to your webserver.
6. Test and revise as necessary.
7. Enjoy!


