<?php
/*******************************
********   OBFUSCAPERY   *******
********************************
* Version 1.10                 *
* (c)2011 Lilaea Media LLC     *
********************************
************************************************************************************
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENTSHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.
***********************************************************************************/
	
	/**** PUT ME IN YOUR PHP INCLUDES FOLDER AND POINT JS AND HTML AT ME ****/
	$emails        = array(              // list emails here
		'info@example.com',
		'sales@example.com',
		'myaddress@somedomain.com'
	);
	$verify_origin = TRUE;               // set to false to bypass http_referer check
	$decode_secret = 'RE41|ySup3RsECrT'; // used to set secret length and decode key from XHR 
	$prefix        = 'obfu_';            // defines the containers for the coded texts.
	$descriptor    = 'obfu_x';           // defines the container for the decode key. 
	                                     // Must match value of JS
/*********************************************************************************/
		
	if (isset($_POST['token'])) 
	{
		$secret = substr(xor_dec($_POST['token'], $decode_secret), 0, strlen($decode_secret));
		$dec = xor_dec($_POST['token'], $secret);
		list($passed_secret, $domain, $size, $prefix) = explode("\t", $dec);
		if (! $verify_origin || verify_origin($domain)) {
			echo xor_enc($secret . "\t" . $size . "\t" . $prefix, $domain);
		}
		exit;

	}

	$secret = generate_secret(strlen($decode_secret));
	
	foreach (array_keys($emails) as $key) 
	{	
	    $padded = generate_secret(rand(1, 10)) . "\t" . $emails[$key] .
			"\t" . generate_secret(rand(1, 10));
		$encrypted = xor_enc($padded, $secret);
		echo '<div style="display:none" id="' . $prefix . $key . '">' . 
		$encrypted . "</div>\n";
	}
	$size = sizeof($emails);
	$decode_info = $decode_secret . "\t" . $_SERVER['HTTP_HOST'] . "\t" . $size . "\t" . $prefix;
	$decode_key = xor_enc($decode_info, $secret);
	echo '<div style="display:none" id="' . $descriptor . '">' . $decode_key . "</div>\n";
		
	function xor_enc($string, $key)
	{
		if (strlen($string) == 0 || strlen($key) == 0) return;
 		while (strlen($key) < strlen($string)) $key .= $key; 
		$hex = '';
		for( $ptr = 0; $ptr < strlen($string); $ptr++)
		{
			$c = ord(substr($string, $ptr, 1));
			$k = ord(substr($key, $ptr, 1));
			$b = $c ^ $k;
		 	$h = substr('0' . dechex($b), -2);
			$hex .= $h;
		}
		return $hex;
	}
	
	function xor_dec($hex, $key)
	{
		if (strlen($hex) == 0 || strlen($key) == 0) return;
		$string = '';
 		while (strlen($key) < strlen($hex)) $key .= $key;
 		for($ptr = 0; $ptr < strlen($hex); $ptr += 2)
		{
			$h = substr($hex, $ptr, 2);
			$b = hexdec($h);
			$k = ord(substr($key, $ptr / 2, 1));
			$c = chr($b ^ $k);
			$string .= $c;
		}
		return $string;
	}
	
	function generate_secret($length) 
	{
        $charlist = array_merge(range(' ', '~'));
        $max = count($charlist) - 1;
        $token = '';
        while (strlen($token) < $length) 
		{
            $token .= $charlist[rand(0, $max)];
        }
        return $token;
    }
	
	function verify_origin($domain) 
	{
		if (isset($_SERVER['HTTP_REFERER'])) {
			$origin = preg_replace("|^https?://|", "", $_SERVER['HTTP_REFERER']);
			$origintree = explode("/", $origin);
			$originparts = explode(".", array_shift($origintree));
			$hostparts   = explode(".", $domain);
			$otld = array_pop($originparts);
			$htld = array_pop($hostparts);
			$odom = array_pop($originparts);
			$hdom = array_pop($hostparts);
			if ($otld == $htld && $odom == $hdom) {
				return true;
			}
		}
		return false;
	}
?>


